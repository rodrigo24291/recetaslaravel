


<?php $__env->startSection('content'); ?>

<div class="container">
    <h2 class="text-center my-3">Administra tus recetas</h2>
    <div class="row my-4">
        <a href="<?php echo e(route('receta.create')); ?>" class="btn btn-primary mx-1">Crear</a>
        <a href="<?php echo e(route('perfil.create')); ?>" class="btn btn-info mx-1">Editar mi perfil</a>
        <a href="<?php echo e(route('perfil.show')); ?>" class="btn btn-danger mx-1">Mi perfil</a>
        
    </div>
    
    <div class="row py-3">
        <table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Titulo</th>
      <th scope="col">Categoria</th>
      <th scope="col">Accion</th>
      
    </tr>
  </thead>
  <tbody>
    
    <?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
  
      <td><?php echo e($receta->id); ?></td>
      <td><?php echo e($receta->titulo); ?></td>
      <td><?php echo e($receta->categoria->titulo); ?></td>
      <td> <a href="<?php echo e(route('receta.show',['receta'=>$receta->id])); ?>"  class="btn btn-success w-50">Ver</a> <eliminar di=<?php echo e($receta->id); ?>></eliminar> <a href="<?php echo e(route('receta.edit',['id'=>$receta->id])); ?>" class="btn btn-primary w-50 mt-1">Editar</a></td>
    </tr>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  </tbody>
</table>
      
     
    </div>
    
     
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pagina\resources\views/receta/index.blade.php ENDPATH**/ ?>