

<?php $__env->startSection('content'); ?>

<h2 class="text-center"><?php echo e(auth::user()->nombre); ?> <?php echo e(auth::user()->apellido); ?></h2>
<div class="container">
<div class="row justify-content-center">
    <div class="col-md-8">
 <div class="image d-flex justify-content-center">       
<?php if(auth::user()->perfil->imagen): ?>        
<img src="<?php echo e(route('perfil.getimagen',['id'=>auth::user()->perfil->imagen])); ?>" class="rounded-circle " alt="" style="height:25rem;width:20rem">
<?php endif; ?>
</div>
<h3 class="text-center my-3">Biografia</h3>
<?php echo auth::user()->perfil->biografia; ?></p>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pagina\resources\views/perfil/show.blade.php ENDPATH**/ ?>