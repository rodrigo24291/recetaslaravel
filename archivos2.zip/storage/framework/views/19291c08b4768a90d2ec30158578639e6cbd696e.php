


<?php $__env->startSection('content'); ?>
<div class="w-100 d-flex flex-column justify-content-center " style=" background-image:linear-gradient(rgba(27, 39, 24, 0.8),rgba(34, 32, 49, 0.8)),url(images/wall.jpg);  background-size: cover; height:70vh; ">
  <div class="container">
    <div class="row d-flex flex-column align-items-center justify-content-center">
      <div class="col-4">
  <form method="POST" action="<?php echo e(route('inicio.busqueda')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label text-white">Buscador de Comida</label>
      <input type="text" class="form-control" id="exampleInputEmail1" name="resultado">
      <button type="submit" class="btn btn-primary my-1">Buscar</button>
    </form>
  </div>
    </div>
  </div>
</div>
</div>
<div class="container">


<h2 class="mt-3">Ultimas recetas</h2>

    <div id="ide" class="owl-carousel">
        <?php $__currentLoopData = $receta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="width: 18rem;">
            <img src="<?php echo e(route('receta.getimagen',['id'=>$recetas->imagen])); ?>" class="card-img-top" style="height:10rem; " alt="...">

           
            <div class="card-body">
              <p class="card-text"><?php echo e(Str::words(strip_tags($recetas->preparacion),10)); ?></p>
              <div class="d-flex justify-content-between">
                <moment valor="<?php echo e($recetas->created_at); ?>"></moment><p><?php echo e($recetas->megusta->count()); ?> Le gusto</p>
              </div>
              <a href="<?php echo e(route('receta.show',['receta'=>$recetas->id])); ?>" class="btn btn-danger w-100 text-center" >Ver mas</a>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fer=> $cates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h2 class="my-3"><?php echo e(Str::title($fer)); ?></h2>
<div id="ide" class="owl-carousel">
    
<?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      
        <div class="card" style="width: 18rem;">
            <img src="<?php echo e(route('receta.getimagen',['id'=>$recetas->imagen])); ?>" class="card-img-top"  style="height:10rem" alt="...">

            <div class="card-body">
              <p class="card-text text-center"><?php echo e(Str::words(strip_tags($recetas->preparacion),10)); ?></p>
              <div class="d-flex justify-content-between">
            <moment valor="<?php echo e($recetas->created_at); ?>"></moment> <p><?php echo e($recetas->megusta->count()); ?> Le gusto</p>
          </div>
          <a href="<?php echo e(route('receta.show',['receta'=>$recetas->id])); ?>" class="btn btn-danger w-100 text-center" >Ver mas</a>
            </div>
            
          </div>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div> 
</div>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pagina\resources\views/inicio/index.blade.php ENDPATH**/ ?>