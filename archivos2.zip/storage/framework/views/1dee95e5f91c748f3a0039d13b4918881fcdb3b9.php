

<?php $__env->startSection('content'); ?>
<div class="container">
  
  <h2 class="text-center my-3"><?php echo e(Str::title($casa->titulo)); ?></h2> 
<div class="row"> 
<?php $__currentLoopData = $ca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
<div class="col-4">
    
    <div class="card mt-4" style="width: 18rem;">
        <img src="<?php echo e(route('receta.getimagen',['id'=>$recetas->imagen])); ?>" class="card-img-top"  style="height:10rem" alt="...">

        <div class="card-body">
          <p class="card-text text-center"><?php echo e(Str::words(strip_tags($recetas->preparacion),10)); ?></p>
          <div class="d-flex justify-content-between">
        <moment valor="<?php echo e($recetas->created_at); ?>"></moment> <p><?php echo e($recetas->megusta->count()); ?> Le gusto</p>
      </div>
      <a href="<?php echo e(route('receta.show',['receta'=>$recetas->id])); ?>" class="btn btn-danger w-100 text-center" >Ver mas</a>
        </div>
        
      </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pagina\resources\views/categoria/show.blade.php ENDPATH**/ ?>