

<?php $__env->startSection('content'); ?>

<h2 class="text-center my-3"><?php echo e(Str::title($receta->titulo)); ?></h2>
<div class="container">
<div class="row justify-content-center">
    <div class="col-md-8">
<img src="<?php echo e(route('receta.getimagen',['id'=>$receta->imagen])); ?>" class="w-100" alt="">
<p><span>Escrito en</span> <?php echo e($receta->categoria->titulo); ?></p>
<p>Autor <?php echo e(Str::title($receta->user->name)); ?> <?php echo e(Str::title($receta->user->surname)); ?></p>
<?php
$data=$receta->created_at    
?>

<moment valor="<?php echo e($data); ?>"></moment>
<h3>Ingredientes</h3>
<p><?php echo $receta->ingredientes; ?></p>
<h3>Preparacion</h3>
<p><?php echo $receta->preparacion; ?></p>

<div class="d-flex justify-content-center flex-column align-items-center">
<like like="<?php echo e($receta->id); ?>"
    likes="<?php echo e($likes); ?>"
    total="<?php echo e($total); ?>">
</like> 
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pagina\resources\views/receta/show.blade.php ENDPATH**/ ?>