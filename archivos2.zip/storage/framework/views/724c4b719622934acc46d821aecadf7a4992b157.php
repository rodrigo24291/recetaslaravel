

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2 class="text-center my-3">Mi perfil</h2>
    
    <div class="row my-4">
        <a href="<?php echo e(route('receta.index')); ?>" class="btn btn-primary mx-1">volver</a>
        
        
    </div>
    
    <div class="row justify-content-center">
        <div class="col-md-8">
         
                    <form method="POST" action="<?php echo e(route('perfil.store',['id'=>auth::user()->id])); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('PUT'); ?>


      
<div class="imag d-flex justify-content-center">
 <?php if(auth::user()->perfil->imagen): ?>                       
<img src="<?php echo e(route('perfil.getimagen',['id'=>auth::user()->perfil->imagen])); ?>" class=" rounded-circle " alt="" style=" height:25rem;width:20rem">
<?php endif; ?>
</div>

            
                        
<div class="form-group row">
    <label for="image" class="col-md-4 col-form-label ">Imagen</label>

    <div class="col-md-10">
        <input id="image" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" value="<?php echo e(old('image')); ?>">

        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

      


                        <div class="form-group row">
                            <label for="biografia" class="col-md-4 col-form-label ">Biografia</label>

                            <div class="col-md-10">
                                <input id="biografia" type="hidden"  name="biografia" value="<?php echo e(old('biografia',auth::user()->perfil->biografia)); ?>" >
<trix-editor input="biografia" class="form-control <?php $__errorArgs = ['biografia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="
height: 14rem !important;
"  ></trix-editor>
                                <?php $__errorArgs = ['biografia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                
                        <div class="form-group row mb-0">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-primary mb-3">
                                  Actualizar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
   
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pagina\resources\views/perfil/edit.blade.php ENDPATH**/ ?>