

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2 class="text-center">Administra tus recetas</h2>
    <div class="row my-4">
        <a href="<?php echo e(route('receta.create')); ?>" class="btn btn-primary mx-1">Crear</a>
        <a href="#" class="btn btn-info mx-1">Editar mi perfil</a>
        <a href="#" class="btn btn-danger mx-1">Mi perfil</a>
        
    </div>
    
    <div class="row py-3">
        <table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Titulo</th>
      <th scope="col">Categoria</th>
      <th scope="col">Acciones</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
  
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
  </tbody>
</table>
        
    </div>
    
    
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravelreceta\pagina\resources\views/receta/index.blade.php ENDPATH**/ ?>